<?php
// Heading
$_['heading_title'] = 'Недавно просмотренные';

// Text
$_['text_tax']      = 'Без НДС:';