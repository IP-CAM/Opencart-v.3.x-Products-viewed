<?php
// Heading
$_['heading_title']    = 'Переглянуті товари';

// Text
$_['text_tax']      = 'Без ПДВ:';