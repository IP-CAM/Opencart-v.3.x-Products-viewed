<?php
// Heading
$_['heading_title']    = 'Viewed products';

// Text
$_['text_tax'] = 'Without VAT:';